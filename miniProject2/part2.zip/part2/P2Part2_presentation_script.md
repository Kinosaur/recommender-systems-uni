# Item-Item Collaborative Filtering — Presentation Script

Hello, my name is [Your Name]. Today I'll present an item-item collaborative filtering recommender system implemented in `main.ipynb` (folder: `miniProject2/part2`).

This script mirrors the notebook structure and provides speaker notes you can read during your presentation. Replace bracketed placeholders before presenting.

---

## Slide / Section 1 — Project Overview

Speaker notes:

- Goal: predict user ratings for unseen items and produce Top-N recommendations.
- Dataset: train and test CSVs (`rating10user91_trainset.csv`, `rating10user91_testset.csv`) located in the parent folder.
- Approach: mean-center ratings per user, compute item-item cosine similarity on centered ratings, predict via weighted sum over neighbors.

---

## Slide / Section 2 — High-level steps

1. Data preparation and profiling
2. Model building: item-item similarity matrix
3. Recommendation generation

I'll now explain each step and include the essential code excerpts from the notebook.

---

## Slide / Section 3 — Data Preparation (Code + Notes)

Speaker notes:

- Load the CSV into a pandas DataFrame.
- Autodetect user/item/rating columns and rename them to `user`, `item`, `rating`.
- Ensure types are strings for IDs and numeric for ratings.
- Mean-center ratings per user and pivot to a user-item matrix where values are `rating_centered`.
- Save the profile CSV `P2Part2_1Profile_Group4.csv`.

Essential notebook code (condensed):

```python
# Core imports
from pathlib import Path
import pandas as pd
import numpy as np

INPUT_PATH = "../rating10user91_trainset.csv"
OUTPUT_PATH = "P2Part2_1Profile_Group4.csv"

df = pd.read_csv(INPUT_PATH)

# Auto-detect columns and rename to canonical names
# ... (same logic as notebook) ...

# Ensure types
df['user'] = df['user'].astype(str)
df['item'] = df['item'].astype(str)
df['rating'] = pd.to_numeric(df['rating'], errors='coerce')
df = df.dropna(subset=['rating']).copy()

# Mean-centering
user_mean = df.groupby('user')['rating'].mean()
df['user_mean'] = df['user'].map(user_mean)
df['rating_centered'] = df['rating'] - df['user_mean']

# Pivot to user-item matrix (centered ratings)
pivot = df.pivot_table(index='user', columns='item', values='rating_centered', aggfunc='mean')

# Save
pivot.to_csv(OUTPUT_PATH, float_format="%.4f", na_rep="")
```

Talking points / why mean-centering:

- Corrects for user bias: users have different rating scales.
- Cosine similarity on mean-centered vectors is equivalent to Pearson correlation across co-rated users.

---

## Slide / Section 4 — Model Building (Similarity Matrix)

Speaker notes:

- The similarity matrix is computed using cosine similarity on mean-centered item vectors.
- For each item pair, we consider only users who rated both items (common raters). If the overlap is below `MIN_OVERLAP`, we skip the pair.
- Optionally apply shrinkage to reduce noise for small overlaps.

Essential notebook code (condensed):

```python
# Settings
GROUP_NO = 4
MODEL_PATH = f"P2Part2_2Model_Group{GROUP_NO}.csv"
MIN_OVERLAP = 1
APPLY_SHRINKAGE = False
SHRINKAGE_LAMBDA = 10

# Using centered pivot from earlier
centered_pivot = pivot
items = centered_pivot.columns.to_list()
values = centered_pivot.values  # rows: users, cols: items

n_items = len(items)
sim_mat = np.zeros((n_items, n_items), dtype=np.float64)

for i in range(n_items):
    vi = values[:, i]
    mask_i = ~np.isnan(vi)
    for j in range(i+1, n_items):
        vj = values[:, j]
        mask_j = ~np.isnan(vj)
        common = mask_i & mask_j
        c = int(common.sum())
        if c < MIN_OVERLAP:
            continue
        vi_c = vi[common]
        vj_c = vj[common]
        num = np.dot(vi_c, vj_c)
        denom_i = np.sqrt(np.dot(vi_c, vi_c))
        denom_j = np.sqrt(np.dot(vj_c, vj_c))
        if denom_i == 0 or denom_j == 0:
            continue
        raw_sim = num / (denom_i * denom_j)
        # optional shrinkage
        if APPLY_SHRINKAGE:
            weight = c / (c + SHRINKAGE_LAMBDA)
            sim_val = weight * raw_sim
        else:
            sim_val = raw_sim
        sim_mat[i, j] = sim_val
        sim_mat[j, i] = sim_val

# Diagonal
for i in range(n_items):
    if np.any(~np.isnan(values[:, i])):
        sim_mat[i, i] = 1.0

sim_df = pd.DataFrame(sim_mat, index=items, columns=items)
sim_df.to_csv(MODEL_PATH, float_format="%.6f")
```

Talking points / checks:

- Explain overlap and why we need it (avoids spurious similarity when few users co-rate both items).
- The diagonal is set to 1 for items with any rating.
- Save model file `P2Part2_2Model_Group4.csv`.

---

## Slide / Section 5 — Recommendation Generation (Predict & Rank)

Speaker notes:

- Load train and test sets, load similarity matrix built previously.
- For each user in the test set, predict ratings for all candidate items (items in the sim matrix not rated by the user in train).
- Use a weighted average of the user's ratings, weighted by similarity between rated item and candidate item.
- Optionally use absolute sums in the denominator and decide whether to include negative similarities.
- Clip predictions to the allowed rating range.

Essential notebook code (condensed):

```python
# Paths
TRAIN_PATH = "../rating10user91_trainset.csv"
TEST_PATH = "../rating10user91_testset.csv"
SIM_PATH = f"P2Part2_2Model_Group{GROUP_NO}.csv"
RECOMMEND_PATH = f"P2Part2_3Recommendation_Group{GROUP_NO}.csv"

# Parameters
USE_ABS_IN_DENOM = True
INCLUDE_NEGATIVE_SIMS = True
CLIP_MIN, CLIP_MAX = 1.0, 10.0
TOP_N = 10

# Load data
train_df = pd.read_csv(TRAIN_PATH)
test_df = pd.read_csv(TEST_PATH)
# normalize columns & types ...

sim_df = pd.read_csv(SIM_PATH, index_col=0)
all_items = set(sim_df.index.tolist())

# Build user_ratings dict and user_mean
user_ratings = (train_df.groupby('user').apply(lambda g: list(zip(g['item'].tolist(), g['rating'].tolist()))).to_dict())
user_mean = train_df.groupby('user')['rating'].mean().to_dict()
global_mean = train_df['rating'].mean()

# Precompute neighbors
item_neighbors = {}
for item in sim_df.index:
    row = sim_df.loc[item].drop(item, errors='ignore')
    row = row[row != 0]
    if not INCLUDE_NEGATIVE_SIMS:
        row = row[row > 0]
    row = row.reindex(row.abs().sort_values(ascending=False).index)
    item_neighbors[item] = list(zip(row.index.tolist(), row.values.tolist()))

# Prediction function

def predict_for_user(user_id):
    rated_pairs = user_ratings.get(user_id, [])
    if not rated_pairs:
        return [(it, global_mean) for it in all_items]
    rated_items = {it for it, _ in rated_pairs}
    candidates = all_items - rated_items
    rdict = dict(rated_pairs)
    num = {}
    denom = {}
    for i, r_ui in rated_pairs:
        neighs = item_neighbors.get(i, [])
        for j, sim_val in neighs:
            if j not in candidates:
                continue
            num[j] = num.get(j, 0.0) + sim_val * r_ui
            denom[j] = denom.get(j, 0.0) + (abs(sim_val) if USE_ABS_IN_DENOM else sim_val)
    preds = []
    u_mean = user_mean.get(user_id, global_mean)
    for j in candidates:
        if j in num and denom.get(j, 0) not in (0, None):
            pred = num[j] / denom[j]
        else:
            pred = u_mean
        pred = max(CLIP_MIN, min(CLIP_MAX, pred))
        preds.append((j, pred))
    preds.sort(key=lambda x: (-x[1], x[0]))
    return preds

# Generate recommendations for test users
records = []
for u in sorted(test_df['user'].unique()):
    top_k = predict_for_user(u)[:TOP_N]
    for item, score in top_k:
        records.append((u, item, score))

recs_df = pd.DataFrame(records, columns=['user','item','pred_rating'])
recs_df.to_csv(RECOMMEND_PATH, index=False, float_format="%.4f")
```

Talking points / caveats:

- Explain denominator choice (absolute vs signed similarity). Using abs helps when negative similarities would cancel positive ones.
- Including negative similarities can worsen or improve predictions depending on data; discuss briefly.
- Fallbacks ensure each user gets recommendations, even cold users.

---

## Slide / Section 6 — Evaluation & Sanity Checks

Speaker notes:

- You can compute RMSE between predicted ratings and actual ratings (from `test_df`) for users/items where ground truth exists.
- Check distribution of similarity values (min/max, fraction negative) to understand behavior.
- Inspect top neighbors for a few example items to validate semantic similarity.

Code hints:

- Use `recs_df` to compare with `test_df` by merging on (user, item) then compute differences.
- Print out `sim_df` summary stats and `top5` neighbors as shown in the notebook.

---

## Slide / Section 7 — Practical Notes & Improvements

Speaker notes:

- Scalability: nested loops over all item pairs is O(n^2) and will be slow for many items. Use sparse representations, approximate nearest neighbors, or matrix algebra (vectorized dot products) to speed up.
- Memory: similarity matrix is dense here. For large item sets, store only top-K neighbors per item.
- Cold-start: the system needs item metadata or other signals to recommend for users with no ratings.
- Normalization: alternative normalizations include z-score or item-wise scaling.

---

## Slide / Section 8 — How to run the notebook

1. Open `miniProject2/part2/main.ipynb` in Jupyter or VS Code.
2. Ensure the train and test CSVs are present in the parent folder: `rating10user91_trainset.csv`, `rating10user91_testset.csv`.
3. Run the cells from top to bottom. The script writes three output files:
   - `P2Part2_1Profile_Group4.csv` (user-item centered profile)
   - `P2Part2_2Model_Group4.csv` (item-item similarity matrix)
   - `P2Part2_3Recommendation_Group4.csv` (Top-N recommendations per test user)

---

## Slide / Section 9 — Closing / Q&A

Speaker notes:

- Summary: We prepared user-centered ratings, computed an item-item similarity model using cosine similarity, and generated Top-10 recommendations using a weighted average of a user's rated items.
- Possible extensions: implement top-K neighbor selection at prediction time, try different similarity metrics (Pearson, adjusted cosine), integrate implicit signals, or add item metadata for cold-start.

---

## Files created

- `miniProject2/part2/P2Part2_presentation_script.md` — This file.

---

If you want, I can also:
- Generate slides from this script (PowerPoint or reveal.js),
- Add code cells that compute RMSE on the test set,
- Extract visualizations (similarity histograms, neighbor examples) for slides.

Tell me which of those you'd like next.
